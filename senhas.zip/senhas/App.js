import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [highPriority, setHighPriority] = useState(0);
  const [mediumPriority, setMediumPriority] = useState(0);
  const [lowPriority, setLowPriority] = useState(0);
  const [running, setRunning] = useState(false);
  const [intervals, setIntervals] = useState([]);

  const startCounters = () => {
    if (!running) {
      setRunning(true);
      const highInterval = setInterval(() => {
        setHighPriority((prev) => prev + 1);
      }, 90000); // 1 minuto e meio

      const mediumInterval = setInterval(() => {
        setMediumPriority((prev) => prev + 1);
      }, 60000); // 1 minuto

      const lowInterval = setInterval(() => {
        setLowPriority((prev) => prev + 1);
      }, 30000); // 30 segundos

      setIntervals([highInterval, mediumInterval, lowInterval]);
    }
  };

  const resetCounters = () => {
    intervals.forEach(clearInterval);
    setRunning(false);
    setHighPriority(0);
    setMediumPriority(0);
    setLowPriority(0);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Alta Prioridade: {highPriority}</Text>
      <Text style={styles.text}>Média Prioridade: {mediumPriority}</Text>
      <Text style={styles.text}>Baixa Prioridade: {lowPriority}</Text>
      <View style={styles.buttons}>
        <TouchableOpacity style={styles.button} onPress={startCounters}>
          <Text style={styles.buttonText}>Iniciar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={resetCounters}>
          <Text style={styles.buttonText}>Reiniciar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  buttons: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 10,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
});
